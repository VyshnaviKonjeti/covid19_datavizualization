# covid-19
Web Page biult using web API which updates the stats of Corona Virus outbreak
## Contributors 
- [koushik avula](https://github.com/koushikavula)
- [Deepthi Raj](https://github.com/deepthi-k-code)
- [Charitha](https://fb.com/charitha.vandrasi)
